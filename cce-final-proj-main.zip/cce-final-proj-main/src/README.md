# Transactional Ballot Casting Voting System
Members: Aurelio, Baman, Caballero, Domingo, Martin 
Next to be implemented:
votes.csv needs to have further privacy functions (make it unable to be read by the devs/admin)
-> for now, due to testing it is visible
Make an admin function to delete candidates
Adjust vote tally / voting form ui to be more aesthetically pleasing
Time complexity and Storage Complexity (show time elapsed to how the program ran in ms/nanos/etc)
add 